// Shared utility functions
export {};
