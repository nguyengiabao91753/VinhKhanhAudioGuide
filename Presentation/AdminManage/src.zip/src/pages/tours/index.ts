export { ToursPage } from './ToursPage';
